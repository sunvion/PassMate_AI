# app/core/security.py
from datetime import datetime, timedelta, timezone
from typing import Optional
import jwt
from jwt.exceptions import InvalidTokenError
from app.core.config import settings

def create_access_token(subject: str) -> str:
    """
    가입/로그인이 확인된 유저에게 줄 우리 서비스 전용 자체 JWT 토큰을 생성합니다.
    - subject: 토큰의 주인이 될 유저의 이메일 주소
    """
    expire = datetime.now(timezone.utc) + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    
    # JWT Payload 구성
    to_encode = {
        "exp": expire,
        "sub": str(subject),
        "iat": datetime.now(timezone.utc)
    }
    
    # 비밀키와 알고리즘으로 암호화 서명 후 반환
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt

def verify_access_token(token: str) -> Optional[str]:
    """
    프론트엔드에서 넘겨받은 JWT 토큰의 위변조 및 만료 여부를 검증하고 파싱합니다.
    - 성공 시: 유저 이메일(sub) 반환
    - 실패 시: None 반환
    """
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        token_user_email: str = payload.get("sub")
        if token_user_email is None:
            return None
        return token_user_email
    except InvalidTokenError:
        # 토큰이 만료되었거나, 서명이 올바르지 않은 경우
        return None